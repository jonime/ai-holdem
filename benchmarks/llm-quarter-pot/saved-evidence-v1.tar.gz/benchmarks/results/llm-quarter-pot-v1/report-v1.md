# LLM quarter-pot retrospective river screen v1

Verdict: **defer**.

2-river-0: fails the all-27 gate. Worst size difference -0.370432534 BB; worst recorded-menu difference -0.111129760 BB. Size sign reversal: true; menu sign reversal: true.

2-river-1: passes the all-27 gate. Worst size difference 0.137384464 BB; worst recorded-menu difference 0.041215339 BB. Size sign reversal: false; menu sign reversal: false.

The size comparison is bet 3 minus bet 4. Recorded-menu differences average all ten actions per menu, retaining checks and unchanged decisions. Each fixture is gated separately; the equal-weight summary is descriptive only.

Retrospective screening of two selected situations; exact conditional synthetic values, no sampling confidence intervals, no independent confirmation or measured playing strength. Ten repetitions do not establish stable LLM frequencies. posterior-best is an optimistic range-informed reference, not an observed LLM response. No causal individual replacements, new calls, production promotion or spending authorization. Failure does not establish universal inferiority.

See analysis-v1.json for every combination, action ranking, worst loss and continuation sensitivity; action checkpoints contain exact branch probabilities, posteriors, equity, terminal values and continuation assumptions. Manifest and checkpoint hashes connect the evidence.
